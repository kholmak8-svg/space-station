// ===============================
// Scene
// ===============================
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

// Camera
const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);

camera.position.z = 15;

// Renderer
const renderer = new THREE.WebGLRenderer({ antialias: true });
const keys = {};
let firstPerson = false;
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);


// ===============================
// Lights
// ===============================
const sunlight = new THREE.DirectionalLight(0xffffff, 2);
sunlight.position.set(10, 15, 10);
scene.add(sunlight);

const ambientLight = new THREE.AmbientLight(0x404040, 1);
scene.add(ambientLight);

// ===============================
// Geometries
// ===============================
const moduleGeometry = new THREE.BoxGeometry(1.5, 1, 2);
const moduleMaterial = new THREE.MeshPhongMaterial({ color: 0x3366cc });

const panelGeometry = new THREE.BoxGeometry(0.2, 2.5, 4);
const panelMaterial = new THREE.MeshPhongMaterial({ color: 0x0033cc });

const towerGeometry = new THREE.CylinderGeometry(0.2, 0.2, 3, 16);
const towerMaterial = new THREE.MeshPhongMaterial({ color: 0xffffff });

const coreGeometry = new THREE.CylinderGeometry(2, 2, 6, 32);
const coreMaterial = new THREE.MeshPhongMaterial({ color: 0x999999 });

// ===============================
// Objects
// ===============================
const stationCore = new THREE.Mesh(coreGeometry, coreMaterial);

// Modules
const module1 = new THREE.Mesh(moduleGeometry, moduleMaterial);
module1.position.set(4, 0, 0);

const module2 = new THREE.Mesh(moduleGeometry, moduleMaterial);
module2.position.set(-4, 0, 0);

const module3 = new THREE.Mesh(moduleGeometry, moduleMaterial);
module3.position.set(0, 0, 4);

const module4 = new THREE.Mesh(moduleGeometry, moduleMaterial);
module4.position.set(0, 0, -4);

const module5 = new THREE.Mesh(moduleGeometry, moduleMaterial);
module5.position.set(3, 2, 3);

const module6 = new THREE.Mesh(moduleGeometry, moduleMaterial);
module6.position.set(-3, -2, -3);

// Panels
const panel1 = new THREE.Mesh(panelGeometry, panelMaterial);
panel1.position.set(7, 0, 0);

const panel2 = new THREE.Mesh(panelGeometry, panelMaterial);
panel2.position.set(-7, 0, 0);

const panel3 = new THREE.Mesh(panelGeometry, panelMaterial);
panel3.position.set(0, 0, 7);

const panel4 = new THREE.Mesh(panelGeometry, panelMaterial);
panel4.position.set(0, 0, -7);

// Towers
const tower1 = new THREE.Mesh(towerGeometry, towerMaterial);
tower1.position.set(1.5, 4.5, 0);

const tower2 = new THREE.Mesh(towerGeometry, towerMaterial);
tower2.position.set(-1.5, 4.5, 0);

// ===============================
// GROUP
// ===============================
const station = new THREE.Group();

station.add(stationCore);
station.add(module1);
station.add(module2);
station.add(module3);
station.add(module4);
station.add(module5);
station.add(module6);

station.add(panel1);
station.add(panel2);
station.add(panel3);
station.add(panel4);

station.add(tower1);
station.add(tower2);

scene.add(station);
// Demonstrate scaling
station.scale.set(1.2, 1.2, 1.2);

// ===============================
// SPACECRAFT
// ===============================
const ships = [];
let shipsPaused = false;

const shipGeometry = new THREE.BoxGeometry(0.5, 0.5, 1);
const shipMaterial = new THREE.MeshPhongMaterial({ color: 0xffaa00 });

for (let i = 0; i < 4; i++) {

    const ship = new THREE.Mesh(shipGeometry, shipMaterial);
    scene.add(ship);

    ships.push({
        mesh: ship,
        angle: i * Math.PI / 2,
        radius: 10
    });
}

// ===============================
// ANIMATION
// ===============================
function animate() {

    requestAnimationFrame(animate);

    // Rotate station
    station.rotation.y += 0.005;

    // Move ships in orbit
  ships.forEach((s) => {

    if (!shipsPaused) {
        s.angle += 0.01;
    }

    s.mesh.position.x = Math.cos(s.angle) * s.radius;
    s.mesh.position.z = Math.sin(s.angle) * s.radius;
    s.mesh.position.y = Math.sin(s.angle * 2) * 1.5;

});

const speed = 0.15;

if (keys["w"]) camera.position.z -= speed;
if (keys["s"]) camera.position.z += speed;

if (keys["a"]) camera.position.x -= speed;
if (keys["d"]) camera.position.x += speed;

if (keys["q"]) camera.position.y += speed;
if (keys["e"]) camera.position.y -= speed;
// Zoom
if (keys["z"] || keys["="]) camera.position.z -= speed;
if (keys["x"] || keys["_"]) camera.position.z += speed;
    renderer.render(scene, camera);
}

window.addEventListener("keydown", (event) => {

    keys[event.key.toLowerCase()] = true;

    if (event.key.toLowerCase() === "v") {

        firstPerson = !firstPerson;

        if (firstPerson) {

            camera.position.set(10,2,2);
camera.lookAt(4, 0, 0);

        } else {

            camera.position.set(0, 0, 15);
            camera.lookAt(0, 0, 0);

        }
    }

});

window.addEventListener("keyup", (event) => {
    keys[event.key.toLowerCase()] = false;
});

animate();

window.addEventListener("keydown", (event) => {

    if (event.key === "p" || event.key === "P") {

        shipsPaused = !shipsPaused;

    }

});
// ===============================
// RESIZE
// ===============================
window.addEventListener("resize", () => {

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);

});